#!/bin/bash

version1=`lsb_release -r | awk '{print $2}'`



openvpn_username_input(){
	read -p "please input your openvpn username type:(ldap user name):" openvpn_username 
	##wget http://software.bj.sensetime.com/openvpn-google-Authenticator/ubuntu-client-and-config/openvpn-install-18.04.tar
	#tar -xvf openvpn-install-18.04.tar
	#cd openvpn-install-18.04 && dpkg -i *
	dpkg -i *.deb

sudo nmcli connection import type openvpn file ./ubuntu-client-and-config/sensetime-sz/sensetime-auth-sz.ovpn
sudo nmcli connection import type openvpn file ./ubuntu-client-and-config/sensetime-bj/sensetime-auth-bj.ovpn
sudo nmcli connection import type openvpn file ./ubuntu-client-and-config/sensetime-hk/sensetime-auth-hk.ovpn
sudo nmcli connection import type openvpn file ./ubuntu-client-and-config/sensetime-sh/sensetime-auth-sh.ovpn
sudo nmcli connection show
sudo nmcli connection modify sensetime-auth-sz +vpn.data username=${openvpn_username}
sudo nmcli connection modify sensetime-auth-bj +vpn.data username=${openvpn_username}
sudo nmcli connection modify sensetime-auth-hk +vpn.data username=${openvpn_username}
sudo nmcli connection modify sensetime-auth-sh +vpn.data username=${openvpn_username}
sudo nmcli connection modify sensetime-auth-sz +vpn.data password-flags=2
sudo nmcli connection modify sensetime-auth-bj +vpn.data password-flags=2
sudo nmcli connection modify sensetime-auth-hk +vpn.data password-flags=2
sudo nmcli connection modify sensetime-auth-sh +vpn.data password-flags=2
}



if [  ${version1} != "18.04" ];then
        echo "The system version is not right!"
        exit;
elif [ `whoami` = "root" ];then
        openvpn_username_input
else
        sudo -i
        openvpn_username_input
fi
